﻿namespace SSPT_SC
{
    internal class Main_Test
    {
        static void Main(string[] args)
        {
            //Uebungen.RechnenUndString();

            //Uebungen.BMI();

            //Uebungen.Koerperoberflaeche();

            //Uebungen.Schaltjahr();

            //Uebungen.CheckName();

            //Uebungen.CheckNameParam("Alex Raul");
            //Uebungen.CheckNameParam("Eva-Maria");
            //Uebungen.CheckNameParam("Leah");

            //Uebungen.InputInt("Geben Sie Ihren Alter ein: ", 0, 100);

            //Uebungen.ToDoVerwaltung();

            //WikiCheck.WikipediaCheck();

            //PortScan.Portscan();

            SSP.Schere_Stein_Papier();
        }
    }
}